"""Base template for Reflex."""
